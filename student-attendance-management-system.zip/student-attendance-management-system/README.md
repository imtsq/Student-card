# Student Attendance Management System

#### 介绍
基于SSM的学生考勤管理系统，是本人的毕业设计，包含学生选课、请假管理，教师开课、签到管理。项目使用的jdk版本为 **JDK1.8** ，数据库为 **MySQL-5.x** 。

#### 技术说明
1. 前端技术：HTML5、JavaScript、CSS、Jquery、Thymeleaf。
2. 后端技术：SpringBoot、SpringMVC、Mybatis。


#### 安装教程

1.  克隆项目到本地。
2.  项目对应的 **SQL文件** 存放于项目根目录下,请将其配置到本地数据库中。
3.  对于intellij idea的使用者，请修改项目配置的Maven主路径。
4.  - 请将jdk版本配置为 **1.8** 。
    - 如果使用的数据库版本为 **8.x** ，请修改pom.xml中的 **MySQL数据库连接池** （mysql-connector-java）依赖项的版本，并修改application.yml中的项为 **spring.datasource.driver-class-name: com.mysql.cj.jdbc.Driver** 。
5.  请修改application.yml中关于 **数据库** 以及 **项目启动端口号** 的配置。

#### 使用说明

1.  运行 **com.lxq** 包下的 **DemoApplication.java** 。

#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_YourID_xxx 分支
3.  提交代码
4.  新建 Pull Request

